<!-- AUTO-GENERATED-CONTENT:START (STARTER) -->
<p align="center">
  <a href="https://www.icfj.org">
    <img alt="ICFJ" src="https://www.icfj.org/themes/custom/icfj/logo.svg" width="60" />
  </a>
</p>
<h1 align="center">
  ICFJ Theme
</h1>
    gatsby react emotion gsap scrolltrigger lottie hamburgers

## 🚀 Quick start

1.  **Develop and Run BrowserSync.**
    Run:
    ```shell
    gatsby develop
    ```
    Visit Browser at:
    `http://localhost:8000`

    View Data at:
    `http://localhost:8000/___graphql`

2.  **Build for Production**
    Run:
    ```shell
    gatsby build
    ```