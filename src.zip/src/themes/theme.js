const theme = {
  //offical color names https://chir.ag/projects/name-that-color
  colors: {
    goldenGrass: "#DDAF24",
    curiousBlue: "#149EE7",
    boulder: "#757575",
    fruitSalad: "#4E954B",
    mineShaft: "#313131",
    sanMarino: "#47609F",
    valencia: "#D44934",
    white: "#fff",
  },
}

export default theme
